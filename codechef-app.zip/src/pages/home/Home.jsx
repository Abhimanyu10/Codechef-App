import React, { Component } from 'react'
import ImageSlider from './image_slider/ImageSlider'
import LoginPage from './login/Login'
import './home.css'
import Login from './login/Login'
export default class Home extends Component {
    render() {
        return (
            <>
                <Login/>
            </>
        )
    }
}
